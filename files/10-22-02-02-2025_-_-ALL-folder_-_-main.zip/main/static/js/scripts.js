document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);

    const response = await fetch('/register', {
        method: 'POST',
        body: formData,
    });

    const result = await response.json();
    document.getElementById('registerResult').innerText = result.message || result.error;
});

document.getElementById('verifyForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);

    const response = await fetch('/verify', {
        method: 'POST',
        body: formData,
    });

    const result = await response.json();
    document.getElementById('verifyResult').innerText = result.message || result.error;
});
