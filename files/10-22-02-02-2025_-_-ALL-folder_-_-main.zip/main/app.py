from flask import Flask, render_template, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from skimage.metrics import structural_similarity as ssim
import cv2
import os

app = Flask(__name__)

# Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///signatures.db'
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

db = SQLAlchemy(app)

# Database Model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    phone = db.Column(db.String(15), nullable=False)
    signature_path = db.Column(db.String(100), nullable=False)

# Initialize database
with app.app_context():
    db.create_all()

# Home Page
@app.route('/')
def index():
    return render_template('index.html')

# Register User and Upload Signature
@app.route('/register', methods=['POST'])
def register():
    data = request.form
    file = request.files['signature']

    if not file:
        return jsonify({'error': 'Signature file is required'}), 400
    
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(file_path)

    user = User(name=data['name'], phone=data['phone'], signature_path=file_path)
    db.session.add(user)
    db.session.commit()
    return render_template('index.html', message="User registered successfully!")

# Verify Signature
@app.route('/verify', methods=['POST'])
def verify():
    file = request.files['signature']

    if not file:
        return jsonify({'error': 'Signature file is required'}), 400
    
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'temp_' + file.filename)
    file.save(file_path)
    
    # Load uploaded signature
    uploaded_image = cv2.imread(file_path, cv2.IMREAD_GRAYSCALE)
    uploaded_image = cv2.resize(uploaded_image, (200, 200))

    users = User.query.all()
    max_similarity = 0
    best_match = None

    for user in users:
        stored_image = cv2.imread(user.signature_path, cv2.IMREAD_GRAYSCALE)
        stored_image = cv2.resize(stored_image, (200, 200))
        similarity = ssim(uploaded_image, stored_image)

        if similarity > max_similarity:
            max_similarity = similarity
            best_match = user
    
    os.remove(file_path)

    if best_match and max_similarity >= 0.75:
        return render_template('success.html', 
                               user_details=best_match, 
                               similarity=f"{max_similarity * 100:.2f}%")
    else:
        return render_template('error.html', 
                               message="No matching signature found. Possible forgery.")

if __name__ == '__main__':
    app.run(debug=True)
