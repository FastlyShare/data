
import React from "react"

const Home = () => {
  
    return (
        <>
            <div className="jumbotron">
                <h1 className="heading1 m-4 text-center">
                    Hello World
                </h1>
            </div>
        </>
    )
  }
  
  export default Home
  